let sum = 0
let a = 5
while (a<=10000) {
 sum=sum +a
 a= a +5   
}
console.log(sum)
alert(sum)