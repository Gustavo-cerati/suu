let suma = parseFloat(0) 
let i= parseFloat(3)
while (i<=10000) {
suma= suma + i 
i=i+3  
}
console.log (suma)
alert(suma)














































































