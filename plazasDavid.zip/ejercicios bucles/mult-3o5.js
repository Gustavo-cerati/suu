let s= 0
let c= 15
while (c<=10000) {
    if (c%5==0 ^ c%3==0) {
       s= s + b 
    }
   c= c+1 
}
console.log(s)
