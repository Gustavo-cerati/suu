x=parseFloat(prompt("ingrese numero a"))
y= parseFloat(prompt("ingrese numero b"))
alert(`la suma es: ${x+y}`) 
alert(`la resta es: ${x-y}`)
alert(`la multiplicacion es: ${x*y}`)
alert(`la division es: ${x/y}`)
alert(`el residuo es: ${x%y}`)
if (y==0) {
    alert("asi nanona, no se puede calcular ni / ni %")
}