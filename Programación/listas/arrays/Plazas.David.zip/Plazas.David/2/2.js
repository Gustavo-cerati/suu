function prom(a) {
    
}