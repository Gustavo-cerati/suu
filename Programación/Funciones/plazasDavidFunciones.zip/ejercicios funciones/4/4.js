function masLarga(a,pe) {
  return String.length (a)
}
  
