function fibonacci(n) {
 while (n>=0) {
    return n + fibonacci (n-1)     
 }
     
}